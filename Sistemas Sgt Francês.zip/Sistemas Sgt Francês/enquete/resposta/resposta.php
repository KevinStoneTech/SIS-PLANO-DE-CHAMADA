<?php
require "../conexao.php";
$pdo = conectar("enquete");
$tabela = "rancho";
$consulta = $pdo->prepare("SELECT * FROM rancho");
$consulta->execute();
$registros = $consulta->fetchAll(PDO::FETCH_ASSOC);
$totalreg = count($registros);

$consulta1 = $pdo->prepare("SELECT * FROM rancho WHERE pergunta = '1'");
$consulta1->execute();
$reg1 = $consulta1->fetchAll(PDO::FETCH_ASSOC);
$totreg1 = count($reg1);

$consulta2 = $pdo->prepare("SELECT * FROM rancho WHERE pergunta = '2'");
$consulta2->execute();
$reg2 = $consulta2->fetchAll(PDO::FETCH_ASSOC);
$totreg2 = count($reg2);

$consulta3 = $pdo->prepare("SELECT * FROM rancho WHERE pergunta = '3'");
$consulta3->execute();
$reg3 = $consulta3->fetchAll(PDO::FETCH_ASSOC);
$totreg3 = count($reg3);

$consulta4 = $pdo->prepare("SELECT * FROM rancho WHERE pergunta = '4'");
$consulta4->execute();
$reg4 = $consulta4->fetchAll(PDO::FETCH_ASSOC);
$totreg4 = count($reg4);

$porc1 = ($totreg1 * 100) / $totalreg;
$porc2 = ($totreg2 * 100) / $totalreg;
$porc3 = ($totreg3 * 100) / $totalreg;
$porc4 = ($totreg4 * 100) / $totalreg;

$dataatual = date("d/m/Y");
$horaatual = date("H:i:s");
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>Enquete</title>
        <!-- Meta Tags -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">
        <meta name="enquete" content="Enquete rancho" />
        <link rel="icon" type="image/png" sizes="192x192" href="images/images.png">
        <link rel="icon" type="image/png" sizes="32x32" href="images/images.png">
        <link rel="icon" type="image/png" sizes="16x16" href="images/images.png">
        <script>
            addEventListener("load", function () {
                setTimeout(hideURLbar, 0);
            }, false);

            function hideURLbar() {
                window.scrollTo(0, 1);
            }
        </script>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- Bootstrap Css -->
        <!-- Bars Css -->
        <link rel="stylesheet" href="css/bar.css">
        <!--// Bars Css -->
        <!-- Calender Css -->
        <link rel="stylesheet" type="text/css" href="css/pignose.calender.css" />
        <!--// Calender Css -->
        <!-- Common Css -->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
        <!--// Common Css -->
        <!-- Nav Css -->
        <link rel="stylesheet" href="css/style4.css">
        <!--// Nav Css -->
        <!-- Fontawesome Css -->
        <link href="css/fontawesome-all.css" rel="stylesheet">
        <!--// Fontawesome Css -->
        <!--// Style-sheets -->

    </head>

    <body>
        <div class="se-pre-con"></div>
        <div class="wrapper">
            <div id="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="outer-w3-agile col-3 mt-3">
                            <h4 class="tittle-w3-agileits mb-4">Resultado</h4>
                            <div class="stats-info stats-body">
                                <ul class="list-unstyled">
                                    <li class="pb-3">Excelente
                                        <span class="float-right"><?php echo(number_format($porc4, 2, ',', '.')); ?>%</span>
                                        <div class="progress progress-striped active progress-right">
                                            <div class="bar green" style="width:<?php echo($porc4); ?>%;"></div>
                                        </div>
                                    </li>
                                    <li class="py-md-4 py-3">Muito bom
                                        <span class="float-right"><?php echo(number_format($porc3, 2, ',', '.')); ?>%</span>
                                        <div class="progress progress-striped active progress-right">
                                            <div class="bar light-blue" style="width:<?php echo($porc3); ?>%;"></div>
                                        </div>
                                    </li>
                                    <li class="py-md-4 py-3">Bom
                                        <span class="float-right"><?php echo(number_format($porc2, 2, ',', '.')); ?>%</span>
                                        <div class="progress progress-striped active progress-right">
                                            <div class="bar yellow" style="width:<?php echo($porc2); ?>%;"></div>
                                        </div>
                                    </li>
                                    <li class="py-md-4 py-3">Ruim
                                        <span class="float-right"><?php echo(number_format($porc1, 2, ',', '.')); ?>%</span>
                                        <div class="progress progress-striped active progress-right">
                                            <div class="bar red" style="width:<?php echo($porc1); ?>%;"></div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-1">

                        </div>
                        <section class="modals-section">
                            <div class="mt-3">
                                <!-- Live Demo -->

                                <!-- Optional Sizes -->
                                <!-- Button trigger modal -->
                                <div class="d-flex justify-content-around mb-5">
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Sugestões <?php echo("(".$totalreg.")");?></button>
                                </div>
                                <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myLargeModalLabel">Sugestões</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                            </div>
                                            <?php
                                            for ($i = 0; $i < $totalreg; $i++) {
                                                $sugestao = $registros[$i];
                                                $tempo = calculaData($sugestao['data'], $sugestao['hora'], $dataatual, $horaatual);
                                                ?>
                                                <div class = "modal-body">
                                                    <?php echo($sugestao['sugestao']); ?>                                                    
                                                    <p class = "paragraph-agileits-w3layouts"><?php echo(" - há " . $tempo); ?></p>
                                                </div>
                                                <?php
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <!--// Browser stats -->
                    </div>
                </div>
                <div class="copyright-w3layouts py-xl-3 py-2 mt-xl-5 mt-4 text-center">
                    <p>Seção de Tecnologia da Informação - 2º Batalhão de Fronteira
                        <a>Desenvolvido pelo 2º Sgt Francês</a>
                    </p>
                </div>
                <!--// Copyright -->
            </div>
        </div>


        <!-- Required common Js -->
        <script src='js/jquery-2.2.3.min.js'></script>
        <!-- //Required common Js -->

        <!-- loading-gif Js -->
        <script src="js/modernizr.js"></script>
        <script>
            //paste this code under head tag or in a seperate js file.
            // Wait for window load
            $(window).load(function () {
                // Animate loader off screen
                $(".se-pre-con").fadeOut("slow");
                ;
            });
        </script>
        <!--// loading-gif Js -->

        <!-- Sidebar-nav Js -->

        <!--// Sidebar-nav Js -->

        <!-- Graph -->
        <script src="js/SimpleChart.js"></script>
        <!--// Graph -->
        <!-- Bar-chart -->
        <script src="js/rumcaJS.js"></script>
        <script src="js/example.js"></script>
        <!--// Bar-chart -->
        <!-- Calender -->
        <script src="js/moment.min.js"></script>
        <script src="js/pignose.calender.js"></script>

        <!-- profile-widget-dropdown js-->
        <script src="js/script.js"></script>
        <!--// profile-widget-dropdown js-->

        <!-- Count-down -->
        <script src="js/simplyCountdown.js"></script>
        <link href="css/simplyCountdown.css" rel='stylesheet' type='text/css' />

        <!-- Js for bootstrap working-->
        <script src="js/bootstrap.min.js"></script>
        <!-- //Js for bootstrap working -->

    </body>

</html>
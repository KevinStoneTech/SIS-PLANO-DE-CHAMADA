<?php

date_default_timezone_set("America/Sao_Paulo");
require "conexao.php";
$pdo = conectar("enquete");
$tabela = "rancho";
$pergunta = filter_input(INPUT_POST, "qualidade");
$sugestao = filter_input(INPUT_POST, "comentarios");
$data = date("d/m/Y");
$hora = date("H:i:s");
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
try {
    $gravddos = $pdo->prepare("INSERT INTO $tabela(data, hora, ip, pergunta, sugestao) "
            . "VALUES (:data, :hora, :ip, :pergunta, :sugestao)");
    $gravddos->bindParam(":data", $data, PDO::PARAM_STR);
    $gravddos->bindParam(":hora", $hora, PDO::PARAM_STR);
    $gravddos->bindParam(":ip", $ip, PDO::PARAM_STR);
    $gravddos->bindParam(":pergunta", $pergunta, PDO::PARAM_STR);
    $gravddos->bindParam(":sugestao", $sugestao, PDO::PARAM_STR);
    $executa = $gravddos->execute();
    if ($executa) {
        //echo 'Dados inseridos com sucesso';
        header('Location: ./resposta/resposta.php');
    } else {
        //echo 'Erro ao inserir dados';
        header('Location: /index.html');
    }
} catch (PDOException $e) {
    echo $e->getMessage();
}

-- MySQL dump 10.15  Distrib 10.0.38-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: helpdesk
-- ------------------------------------------------------
-- Server version	10.0.38-MariaDB-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chamado`
--

DROP TABLE IF EXISTS `chamado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chamado` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `numchamado` varchar(20) NOT NULL,
  `situacao` varchar(1) NOT NULL,
  `idservico` int(6) NOT NULL,
  `idsolicitante` int(6) NOT NULL,
  `idsecao` int(6) NOT NULL,
  `dataabertura` varchar(10) NOT NULL,
  `datafechamento` varchar(10) NOT NULL,
  `horaabertura` varchar(8) NOT NULL,
  `horafechamento` varchar(8) NOT NULL,
  `tecnico` int(6) NOT NULL,
  `assunto` varchar(100) NOT NULL,
  `idetiqueta` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `chamado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etiqueta`
--

DROP TABLE IF EXISTS `etiqueta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etiqueta` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `numero` varchar(3) NOT NULL,
  `disponivel` varchar(1) NOT NULL,
  `totalchamados` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etiqueta`
--

LOCK TABLES `etiqueta` WRITE;
/*!40000 ALTER TABLE `etiqueta` DISABLE KEYS */;
INSERT INTO `etiqueta` VALUES (1,'001','N',2),(2,'002','N',0),(3,'003','N',1),(4,'004','N',0),(5,'005','N',0),(6,'006','N',0),(7,'007','N',4),(8,'008','N',0),(9,'009','N',0),(10,'010','N',0),(11,'011','N',0),(12,'012','N',0),(13,'013','N',0),(14,'014','N',0),(15,'015','N',0),(16,'016','N',0),(17,'017','N',0),(18,'018','N',0),(19,'019','N',0),(20,'020','N',0),(21,'021','N',0),(22,'022','N',0),(23,'023','N',0),(24,'024','N',0),(25,'025','N',0),(26,'026','N',0),(27,'027','N',0),(28,'028','N',0),(29,'029','N',0),(30,'030','N',0),(31,'031','N',0),(32,'032','N',1),(33,'033','N',1),(34,'034','N',0),(35,'035','N',9),(36,'036','N',1),(37,'037','N',2),(38,'038','N',4),(39,'039','N',6),(40,'040','N',0),(41,'041','N',0),(42,'042','N',0),(43,'043','N',1),(44,'044','N',0),(45,'045','N',1),(46,'046','N',4),(47,'047','N',0),(48,'048','N',1),(49,'049','N',1),(50,'050','N',0),(51,'051','N',0),(52,'052','N',1),(53,'053','N',1),(54,'054','N',0),(55,'055','N',1),(56,'056','N',1),(57,'057','N',1),(58,'058','N',0),(59,'059','N',2),(60,'060','N',0),(61,'061','N',0),(62,'062','N',2),(63,'063','N',4),(64,'064','N',3),(65,'065','N',1),(66,'066','N',0),(67,'067','N',2),(68,'068','N',1),(69,'069','N',3),(70,'070','N',0),(71,'071','N',0),(72,'072','N',9),(73,'073','N',1),(74,'074','N',2),(75,'075','N',6),(76,'076','N',5),(77,'077','N',1),(78,'078','N',0),(79,'079','N',0),(80,'080','N',3),(81,'081','N',3),(82,'082','N',5),(83,'083','N',3),(84,'084','N',5),(85,'085','N',2),(86,'086','N',0),(87,'087','N',0),(88,'088','N',4),(89,'089','N',2),(90,'090','N',0),(91,'091','N',1),(92,'092','N',3),(93,'093','N',0),(94,'094','N',1),(95,'095','N',3),(96,'096','N',1),(97,'097','N',0),(98,'098','N',1),(99,'099','N',1),(100,'100','N',1),(101,'101','N',2),(102,'102','N',2),(103,'103','N',1),(104,'104','N',1),(105,'105','N',1),(106,'106','N',0),(107,'107','N',1),(108,'108','N',2),(109,'109','N',2),(110,'110','N',4),(111,'111','N',1),(112,'112','N',2),(113,'113','N',1),(114,'114','N',4),(115,'115','N',3),(116,'116','N',6),(117,'117','N',5),(118,'118','N',4),(119,'119','N',1),(120,'120','N',0),(121,'121','N',1),(122,'122','N',2),(123,'123','N',4),(124,'124','N',2),(125,'125','N',2),(126,'126','N',5),(127,'127','N',0),(128,'128','N',5),(129,'129','N',1),(130,'130','N',1),(131,'131','N',0),(132,'132','N',3),(133,'133','N',1),(134,'134','N',3),(135,'135','N',0),(136,'136','N',1),(137,'137','N',4),(138,'138','N',6),(139,'139','N',3),(140,'140','N',2),(141,'141','N',0),(142,'142','N',0),(143,'143','N',0),(144,'144','N',0),(145,'145','N',3),(146,'146','N',0),(147,'147','N',5),(148,'148','N',0),(149,'149','N',2),(150,'150','N',4),(151,'151','N',0),(152,'152','N',3),(153,'153','N',1),(154,'154','N',2),(155,'155','N',0),(156,'156','N',0),(157,'157','N',0),(158,'158','N',0),(159,'159','N',2),(160,'160','N',1),(161,'161','N',0),(162,'162','N',2),(163,'163','N',2),(164,'164','N',4),(165,'165','N',2),(166,'166','N',0),(167,'167','N',0),(168,'168','N',2),(169,'169','N',0),(170,'170','N',0),(171,'171','N',0),(172,'172','N',1),(173,'173','N',2),(174,'174','N',0),(175,'175','N',3),(176,'176','N',0),(177,'177','N',1),(178,'178','N',2),(179,'179','N',0),(180,'180','N',0),(181,'181','N',0),(182,'182','N',0),(183,'183','N',0),(184,'184','N',2),(185,'185','N',0),(186,'186','N',2),(187,'187','N',0),(188,'188','N',0),(189,'189','N',0),(190,'190','N',0),(191,'191','N',0),(192,'192','N',1),(193,'193','N',1),(194,'194','N',0),(195,'195','N',0),(196,'196','N',0),(197,'197','N',0),(198,'198','N',1),(199,'199','N',0),(200,'200','N',0),(201,'201','N',0),(202,'202','N',0),(203,'203','N',0),(204,'204','N',0),(205,'205','N',0),(206,'206','N',1),(207,'207','N',1),(208,'208','N',0),(209,'209','N',1),(210,'210','N',2),(211,'211','N',0),(212,'212','N',2),(213,'213','N',1),(214,'214','N',0),(215,'215','N',0),(216,'216','N',0),(217,'217','N',2),(218,'218','N',7),(219,'219','N',0),(220,'220','N',1),(221,'221','N',0),(222,'222','N',1),(223,'223','N',3),(224,'224','N',0),(225,'225','N',0),(226,'226','N',2),(227,'227','N',0),(228,'228','N',0),(229,'229','N',0),(230,'230','N',2),(231,'231','N',4),(232,'232','N',1),(233,'233','N',0),(234,'234','N',0),(235,'235','N',1),(236,'236','N',0),(237,'237','N',0),(238,'238','N',0),(239,'239','N',0),(240,'240','N',0),(241,'241','N',0),(242,'242','N',0),(243,'243','N',0),(244,'244','N',0),(245,'245','N',0),(246,'246','N',0),(247,'247','N',0),(248,'248','N',0),(249,'249','N',0),(250,'250','N',0),(251,'251','N',0),(252,'252','N',0),(253,'253','N',0),(254,'254','N',0),(255,'255','N',0);
/*!40000 ALTER TABLE `etiqueta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historico`
--

DROP TABLE IF EXISTS `historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historico` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `numchamado` varchar(20) NOT NULL,
  `texto` longtext NOT NULL,
  `anexo` varchar(200) NOT NULL,
  `data` varchar(10) NOT NULL,
  `hora` varchar(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historico`
--

/*!40000 ALTER TABLE `historico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip`
--

DROP TABLE IF EXISTS `ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `disponivel` varchar(1) NOT NULL,
  `quemusa` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip`
--

LOCK TABLES `ip` WRITE;
/*!40000 ALTER TABLE `ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) NOT NULL,
  `qtditem` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material`
--

DROP TABLE IF EXISTS `material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `material` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `iditem` int(6) NOT NULL,
  `idetiqueta` int(6) NOT NULL,
  `idso` int(6) NOT NULL,
  `descricao` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material`
--

LOCK TABLES `material` WRITE;
/*!40000 ALTER TABLE `material` DISABLE KEYS */;
/*!40000 ALTER TABLE `material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secao`
--

DROP TABLE IF EXISTS `secao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secao` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `secao` varchar(100) NOT NULL,
  `qtdchamados` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secao`
--

LOCK TABLES `secao` WRITE;
/*!40000 ALTER TABLE `secao` DISABLE KEYS */;
INSERT INTO `secao` VALUES (1,'S1',25),(2,'S2',9),(3,'S3',10),(4,'S4',11),(5,'SeÃ§Ã£o de Tecnologia da InformaÃ§Ã£o',1),(6,'ComunicaÃ§Ã£o Social',16),(7,'Comandante',1),(8,'Subcomandante',0),(9,'Adjunto de Comando',2),(10,'Fiscal Administrativo',25),(11,'Fusex',30),(12,'Gabinete OdontolÃ³gico',3),(13,'FarmÃ¡cia',11),(14,'LaboratÃ³rio',2),(15,'SeÃ§Ã£o de SaÃºde',34),(16,'SeÃ§Ã£o de Inativos e Pensionistas',17),(17,'Mobilizadora',8),(18,'IdentificaÃ§Ã£o',5),(19,'Tesouraria',9),(20,'SALC',19),(21,'Conformidade',7),(22,'PelotÃ£o  de Transporte',6),(23,'SeÃ§Ã£o Fluvial',3),(24,'RÃ¡dio Operador',0),(25,'PelotÃ£o de ComunicaÃ§Ãµes',0),(26,'1Âª Cia Fuz',20),(27,'2Âª Cia Fuz',19),(28,'3Âª Cia Fuz',21),(29,'SFPC',2),(30,'CCAp',21),(31,'Base Administrativa',68),(32,'CED',39),(33,'Pagamento de Pessoal',6),(34,'Banda de MÃºsica',9),(35,'Almoxarifado',7),(36,'EstaÃ§Ã£o RÃ¡dio',0),(37,'Secretaria',6),(38,'Aprovisionamento',1),(39,'Sala de ImpressÃ£o',1);
/*!40000 ALTER TABLE `secao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servico`
--

DROP TABLE IF EXISTS `servico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servico` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `servico` varchar(100) NOT NULL,
  `qtdservico` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servico`
--

LOCK TABLES `servico` WRITE;
/*!40000 ALTER TABLE `servico` DISABLE KEYS */;
INSERT INTO `servico` VALUES (1,'ManutenÃ§Ã£o de Computador',133),(2,'Impressora',47),(3,'SPED',81),(4,'Suporte TÃ©cnico',70),(5,'Problemas de rede',54),(6,'Sistemas Internos',80),(7,'Zimbra',7),(8,'Telefonia',2);
/*!40000 ALTER TABLE `servico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sistoper`
--

DROP TABLE IF EXISTS `sistoper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sistoper` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `sistema` varchar(100) NOT NULL,
  `qtdsisop` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sistoper`
--

LOCK TABLES `sistoper` WRITE;
/*!40000 ALTER TABLE `sistoper` DISABLE KEYS */;
INSERT INTO `sistoper` VALUES (1,'Ubuntu 17.10 amd64',0),(2,'Ubuntu 16.04.4 i386',0),(3,'Ubuntu 16.04.4 amd64',0),(4,'Windows 7 amd64',0),(5,'Windows 7 i386',0),(6,'Windows 10',0),(7,'Debian 8.3 i386',0),(8,'Debian 9.4.0 i386',0),(9,'Debian 9.4.0 amd64',0),(10,'Ubuntu 17.04 amd64',0),(11,'Debian 8.3 amd64',0);
/*!40000 ALTER TABLE `sistoper` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-03  8:46:49

-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 11-Out-2019 às 14:25
-- Versão do servidor: 10.4.8-MariaDB
-- versão do PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `membros`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bairros`
--

CREATE TABLE `bairros` (
  `id` int(5) NOT NULL,
  `bairro` varchar(50) NOT NULL,
  `setor` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `bairros`
--

INSERT INTO `bairros` (`id`, `bairro`, `setor`) VALUES
(1, 'Centro', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `estados`
--

CREATE TABLE `estados` (
  `id` int(5) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `sigla` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `estados`
--

INSERT INTO `estados` (`id`, `nome`, `sigla`) VALUES
(1, 'Acre', 'AC'),
(2, 'Alagoas', 'AL'),
(3, 'Amazonas', 'AM'),
(4, 'AmapÃ¡', 'AP'),
(5, 'Bahia', 'BA'),
(6, 'CearÃ¡', 'CE'),
(7, 'Distrito Federal', 'DF'),
(8, 'EspÃ­rito Santo', 'ES'),
(9, 'GoiÃ¡s', 'GO'),
(10, 'MaranhÃ£o', 'MA'),
(11, 'Minas Gerais', 'MG'),
(12, 'Mato Grosso do Sul', 'MS'),
(13, 'Mato Grosso', 'MT'),
(14, 'ParÃ¡', 'PA'),
(15, 'ParaÃ­ba', 'PB'),
(16, 'Pernambuco', 'PE'),
(17, 'PiauÃ­', 'PI'),
(18, 'ParanÃ¡', 'PR'),
(19, 'Rio de Janeiro', 'RJ'),
(20, 'Rio Grande do Norte', 'RN'),
(21, 'RondÃ´nia', 'RO'),
(22, 'Roraima', 'RR'),
(23, 'Rio Grande do Sul', 'RS'),
(24, 'Santa Catarina', 'SC'),
(25, 'Sergipe', 'SE'),
(26, 'SÃ£o Paulo', 'SP'),
(27, 'Tocantins', 'TO');

-- --------------------------------------------------------

--
-- Estrutura da tabela `logins`
--

CREATE TABLE `logins` (
  `id` int(11) NOT NULL,
  `idmembro` int(5) NOT NULL,
  `data` varchar(10) NOT NULL,
  `hora` varchar(10) NOT NULL,
  `sistema` varchar(50) NOT NULL,
  `ip` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `logins`
--

INSERT INTO `logins` (`id`, `idmembro`, `data`, `hora`, `sistema`, `ip`) VALUES
(1, 1, '11/10/2019', '08:24:39', 'U0lTVEVNQSBQTEFOTyBERSBDSEFNQURBUw==', '::1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `postograd`
--

CREATE TABLE `postograd` (
  `id` int(6) NOT NULL,
  `postograd` varchar(20) NOT NULL,
  `pgradsimples` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `postograd`
--

INSERT INTO `postograd` (`id`, `postograd`, `pgradsimples`) VALUES
(1, 'General', 'GEN'),
(2, 'Coronel', 'CEL'),
(3, 'Tenente Coronel', 'TC'),
(4, 'Major', 'MAJ'),
(5, 'CapitÃ£o', 'CAP'),
(6, '1Âº Tenente', '1Âº TEN'),
(7, '2Âº Tenente', '2Âº TEN'),
(8, 'Aspirante a Oficial', 'ASP OF'),
(9, 'Subtenente', 'ST'),
(10, '1Âº Sargento', '1Âº SGT'),
(11, '2Âº Sargento', '2Âº SGT'),
(12, '3Âº Sargento', '3Âº SGT'),
(13, 'Cabo NB', 'CB NB'),
(14, 'Cabo EV', 'CB EV'),
(15, 'Soldado NB', 'SD NB'),
(16, 'Soldado EV', 'SD EV');

-- --------------------------------------------------------

--
-- Estrutura da tabela `relatorios`
--

CREATE TABLE `relatorios` (
  `id` int(11) NOT NULL,
  `data` varchar(10) COLLATE utf8mb4_bin NOT NULL,
  `hora` varchar(10) COLLATE utf8mb4_bin NOT NULL,
  `ip` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `responsavel` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `sistema` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `obs` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `setores`
--

CREATE TABLE `setores` (
  `id` int(4) NOT NULL,
  `setor` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `setores`
--

INSERT INTO `setores` (`id`, `setor`) VALUES
(1, 'Alfa'),
(2, 'Bravo'),
(3, 'Charlie'),
(4, 'Delta'),
(5, 'Echo'),
(6, 'Foxtrot'),
(7, 'Golf'),
(8, 'Hotel'),
(9, 'India'),
(10, 'Juliet'),
(11, 'Kilo'),
(12, 'Lima');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subunidade`
--

CREATE TABLE `subunidade` (
  `id` int(4) NOT NULL,
  `descricao` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `subunidade`
--

INSERT INTO `subunidade` (`id`, `descricao`) VALUES
(1, 'CCAP'),
(2, '1Âª Cia Fuz'),
(3, '2Âª Cia Fuz'),
(4, '3Âª Cia Fuz'),
(5, 'BASE'),
(6, 'CED'),
(7, 'Banda de MÃºsica');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(6) NOT NULL,
  `identidade` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  `idsubunidade` int(4) NOT NULL,
  `idpgrad` int(5) NOT NULL,
  `nomeguerra` varchar(50) NOT NULL,
  `acessorancho` varchar(1) NOT NULL,
  `contarancho` varchar(1) NOT NULL,
  `acessocaveira` varchar(1) NOT NULL,
  `contacaveira` varchar(1) NOT NULL,
  `acessoservico` varchar(1) NOT NULL,
  `contaservico` varchar(1) NOT NULL,
  `acessopchamada` varchar(1) NOT NULL,
  `contapchamada` varchar(1) NOT NULL,
  `userativo` varchar(1) NOT NULL,
  `nomecompleto` varchar(100) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `bairro` int(5) NOT NULL,
  `cidade` varchar(50) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `celular` varchar(15) NOT NULL,
  `fixo` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `datanascimento` varchar(10) NOT NULL,
  `foto` varchar(50) NOT NULL,
  `acessohd` varchar(1) NOT NULL,
  `contahd` varchar(1) NOT NULL,
  `datanascimento2` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `identidade`, `senha`, `idsubunidade`, `idpgrad`, `nomeguerra`, `acessorancho`, `contarancho`, `acessocaveira`, `contacaveira`, `acessoservico`, `contaservico`, `acessopchamada`, `contapchamada`, `userativo`, `nomecompleto`, `endereco`, `bairro`, `cidade`, `estado`, `celular`, `fixo`, `email`, `datanascimento`, `foto`, `acessohd`, `contahd`, `datanascimento2`) VALUES
(1, 'MTIz', 'MTIz', 0, 12, 'Adm', 'S', '4', ' ', ' ', '', '', 'S', '3', 'S', 'Adm', '', 0, '', '', '', '', '', '', '', 'S', '3', '');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `bairros`
--
ALTER TABLE `bairros`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `estados`
--
ALTER TABLE `estados`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `postograd`
--
ALTER TABLE `postograd`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `relatorios`
--
ALTER TABLE `relatorios`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `setores`
--
ALTER TABLE `setores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `subunidade`
--
ALTER TABLE `subunidade`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `bairros`
--
ALTER TABLE `bairros`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `estados`
--
ALTER TABLE `estados`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `logins`
--
ALTER TABLE `logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `postograd`
--
ALTER TABLE `postograd`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `relatorios`
--
ALTER TABLE `relatorios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `setores`
--
ALTER TABLE `setores`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `subunidade`
--
ALTER TABLE `subunidade`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

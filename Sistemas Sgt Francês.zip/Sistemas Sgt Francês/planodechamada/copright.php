<div class="text-center">
    <a href="#" class="on-click">
        <h8><?php echo("Seu IP: ".$_SESSION['user_ip']."<br> Host:".$_SESSION['acesuser']);?></h8>
    </a>
</div>
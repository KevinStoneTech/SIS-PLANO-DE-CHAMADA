<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

phpinfo();
echo(base64_encode('2º Sgt Francês'));

echo(base64_decode('MsK6IFNndCBGcmFuY8Oqcw=='));
?>
<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function conectar($database) {
    define('DB_DRIVER', 'mysql');
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PWD', '#');
    define('DB_DATABASE', $database);
    try {
        $pdo = new PDO(DB_DRIVER . ':host=' . DB_HOST . ';dbname=' . DB_DATABASE, DB_USER, DB_PWD);

        if ($pdo) {
            //echo("Conexão realizada com sucesso!");
            return $pdo;
        } else {
            session_destroy();
            $msgerro = base64_encode('Erro na tentativa de acesso ao servidor!');
            header('Location: signin.php?token=' . $msgerro);
        }
    } catch (PDOException $exc) {
        session_destroy();
        $msgerro = base64_encode($exc->getMessage());
        header('Location: signin.php?token=' . $msgerro);
        //echo "Problemas na conexão!";
        //echo $exc->getMessage();
    }
}

function date_converter($_date = null) {
    $format = '/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/';
    if ($_date != null && preg_match($format, $_date, $partes)) {
        return $partes[3] . '/' . $partes[2] . '/' . $partes[1];
    }
    return false;
}

?>

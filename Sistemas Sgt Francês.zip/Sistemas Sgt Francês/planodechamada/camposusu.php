<?php
$campo[1] = "nome";
$campo[2] = "guerra";
$campo[3] = "pgrad";
$campo[4] = "endereco";
$campo[5] = "bairro";
$campo[6] = "cidade";
$campo[7] = "estado";
$campo[8] = "subunidade";
$campo[9] = "email";
$campo[10] = "fonefixo";
$campo[11] = "fonecelular";
$campo[12] = "identidade";
$campo[13] = "datanascimento";
$campo[14] = "S"; //Acesso ao Arranchamento
$campo[15] = "1"; //Tipo de conta padrão do arranchamento
$campo[16] = "S"; //Usuario Ativo
$campo[17] = base64_encode($campo[12]);
?>

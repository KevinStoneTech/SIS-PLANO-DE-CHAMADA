<div class="text-center">
        <h8><?php echo("Seu IP: ".$_SESSION['user_ip2']."<br> Host:".$_SESSION['acesuser2']);?></h8>
</div>
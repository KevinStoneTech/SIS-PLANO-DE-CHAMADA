<?php
$arquivo = "contador.txt";
$handle = fopen($arquivo, "r+");
$data = fread($handle, 512);
$contador = $data + 1;
fseek($handle, 0);
fwrite($handle, $contador);
fclose($handle);
?> 
<!DOCTYPE html>
<!--[if IE 8 ]>
<html lang="en" class="no-js ie8"></html><![endif]-->
<!--[if IE 9 ]>
<html lang="en" class="no-js ie9"></html><![endif]-->
<html class="no-js" lang="en">

    <head>
        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="author" content="createIT">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="format-detection" content="telephone=no">
        <script src="cdn-cgi/apps/head/CZ3CFmKcMfCcupa_86mxMcuVsN8.js"></script><link rel="shortcut icon" href="assets/images/favicon.ico">
        <link rel="apple-touch-icon" href="assets/images/favicon.png">
        <title>Aniversariantes do Mês</title>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <style>
            .ct-preloader {
                position: fixed;
                z-index: 998;
                width: 100%;
                width: 100vw;
                height: 100%;
                height: 100vh;
                background-color: #111111;
                overflow: hidden;
                display: table;
                text-align: center;
            }
            div.ct-preloader__inner {
                position: relative;
                display: table-cell;
                vertical-align: middle;
                margin: auto;
                width: 142px;
                height: 142px;
            }
            div.ct-preloader__spinner {
                -moz-animation: rotate 10s infinite linear;
                -webkit-animation: rotate 10s infinite linear;
                animation: rotate 10s infinite linear;
                margin: auto;
                width: 142px;
                height: 142px;
            }
            div.ct-preloader__spinner i {
                -moz-animation: rotate 3s infinite cubic-bezier(0.09, 0.6, 0.8, 0.03);
                -webkit-animation: rotate 3s infinite cubic-bezier(0.09, 0.6, 0.8, 0.03);
                animation: rotate 3s infinite cubic-bezier(0.09, 0.6, 0.8, 0.03);
                -moz-transform-origin: 50% 100% 0;
                -webkit-transform-origin: 50% 100% 0;
                transform-origin: 50% 100% 0;
                position: absolute;
                display: inline-block;
                top: 50%;
                left: 50%;
                border: solid 6px transparent;
                border-bottom: none;
            }
            div.ct-preloader__spinner i:nth-child(1) {
                -moz-animation-timing-function: cubic-bezier(0.09, 0.3, 0.12, 0.03);
                -webkit-animation-timing-function: cubic-bezier(0.09, 0.3, 0.12, 0.03);
                animation-timing-function: cubic-bezier(0.09, 0.3, 0.12, 0.03);
                width: 44px;
                height: 22px;
                margin-top: -22px;
                margin-left: -22px;
                border-color: #2172b8;
                border-top-left-radius: 36px;
                border-top-right-radius: 36px;
            }
            div.ct-preloader__spinner i:nth-child(2) {
                -moz-animation-timing-function: cubic-bezier(0.09, 0.6, 0.24, 0.03);
                -webkit-animation-timing-function: cubic-bezier(0.09, 0.6, 0.24, 0.03);
                animation-timing-function: cubic-bezier(0.09, 0.6, 0.24, 0.03);
                width: 58px;
                height: 29px;
                margin-top: -29px;
                margin-left: -29px;
                border-color: #18a39b;
                border-top-left-radius: 42px;
                border-top-right-radius: 42px;
            }
            div.ct-preloader__spinner i:nth-child(3) {
                -moz-animation-timing-function: cubic-bezier(0.09, 0.9, 0.36, 0.03);
                -webkit-animation-timing-function: cubic-bezier(0.09, 0.9, 0.36, 0.03);
                animation-timing-function: cubic-bezier(0.09, 0.9, 0.36, 0.03);
                width: 72px;
                height: 36px;
                margin-top: -36px;
                margin-left: -36px;
                border-color: #82c545;
                border-top-left-radius: 48px;
                border-top-right-radius: 48px;
            }
            div.ct-preloader__spinner i:nth-child(4) {
                -moz-animation-timing-function: cubic-bezier(0.09, 1.2, 0.48, 0.03);
                -webkit-animation-timing-function: cubic-bezier(0.09, 1.2, 0.48, 0.03);
                animation-timing-function: cubic-bezier(0.09, 1.2, 0.48, 0.03);
                width: 86px;
                height: 43px;
                margin-top: -43px;
                margin-left: -43px;
                border-color: #f8b739;
                border-top-left-radius: 54px;
                border-top-right-radius: 54px;
            }
            div.ct-preloader__spinner i:nth-child(5) {
                -moz-animation-timing-function: cubic-bezier(0.09, 1.5, 0.6, 0.03);
                -webkit-animation-timing-function: cubic-bezier(0.09, 1.5, 0.6, 0.03);
                animation-timing-function: cubic-bezier(0.09, 1.5, 0.6, 0.03);
                width: 100px;
                height: 50px;
                margin-top: -50px;
                margin-left: -50px;
                border-color: #f06045;
                border-top-left-radius: 60px;
                border-top-right-radius: 60px;
            }
            div.ct-preloader__spinner i:nth-child(6) {
                -moz-animation-timing-function: cubic-bezier(0.09, 1.8, 0.72, 0.03);
                -webkit-animation-timing-function: cubic-bezier(0.09, 1.8, 0.72, 0.03);
                animation-timing-function: cubic-bezier(0.09, 1.8, 0.72, 0.03);
                width: 114px;
                height: 57px;
                margin-top: -57px;
                margin-left: -57px;
                border-color: #ed2861;
                border-top-left-radius: 66px;
                border-top-right-radius: 66px;
            }
            div.ct-preloader__spinner i:nth-child(7) {
                -moz-animation-timing-function: cubic-bezier(0.09, 2.1, 0.84, 0.03);
                -webkit-animation-timing-function: cubic-bezier(0.09, 2.1, 0.84, 0.03);
                animation-timing-function: cubic-bezier(0.09, 2.1, 0.84, 0.03);
                width: 128px;
                height: 64px;
                margin-top: -64px;
                margin-left: -64px;
                border-color: #c12680;
                border-top-left-radius: 72px;
                border-top-right-radius: 72px;
            }
            div.ct-preloader__spinner i.ct-preloader__8 {
                -moz-animation-timing-function: cubic-bezier(0.09, 2.4, 0.96, 0.03);
                -webkit-animation-timing-function: cubic-bezier(0.09, 2.4, 0.96, 0.03);
                animation-timing-function: cubic-bezier(0.09, 2.4, 0.96, 0.03);
                width: 142px;
                height: 71px;
                margin-top: -71px;
                margin-left: -71px;
                border-color: #5d3191;
                border-top-left-radius: 78px;
                border-top-right-radius: 78px;
            }

            @-moz-keyframes rotate {
                to {
                    -moz-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
            @-webkit-keyframes rotate {
                to {
                    -webkit-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
            @keyframes rotate {
                to {
                    -moz-transform: rotate(360deg);
                    -ms-transform: rotate(360deg);
                    -webkit-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
        </style>
        <link rel="stylesheet" href="assets/css/style.css">
        <!--[if lt IE 9]>
        <script src="assets/js/html5shiv.min.js"></script>
        <script src="assets/js/respond.min.js"></script>
        <script src="assets/js/es5-shim.min.js"></script><![endif]-->
    </head>

    <body class="cssAnimate">
        <!--[if lt IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <div class="ct-preloader">
            <div class="ct-preloader__inner">
                <div class="ct-preloader__spinner">
                    <i class="ct-preloader__1"></i>
                    <i class="ct-preloader__2"></i>
                    <i class="ct-preloader__3"></i>
                </div>
            </div>
        </div>
        <!-- ******************** -->
        <!-- *** Page Wrapper *** -->
        <!-- ******************** -->
        <div id="ct-js-wrapper" class="ct-page-wrapper">
            <!-- *** Page Navigation *** -->            
            <!-- *** Page Header ***-->
            <header data-parallax="30" class="ct-page-header ct-page-header--big">
                <svg viewBox="0 0 100 100" preserveAspectRatio="none" class="ct-page-header__svg">
                <path d="M0,100 L 100,100 100,0 Z"></path>
                </svg>
                <div class="ct-page-header__inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <?php
                                $mesatual = date("m");
                                if ($mesatual == "01") {
                                    $mes = "Janeiro";
                                }
                                if ($mesatual == "02") {
                                    $mes = "Fevereiro";
                                }
                                if ($mesatual == "03") {
                                    $mes = "Mar&ccedilo";
                                }
                                if ($mesatual == "04") {
                                    $mes = "Abril";
                                }
                                if ($mesatual == "05") {
                                    $mes = "Maio";
                                }
                                if ($mesatual == "06") {
                                    $mes = "Junho";
                                }
                                if ($mesatual == "07") {
                                    $mes = "Julho";
                                }
                                if ($mesatual == "08") {
                                    $mes = "Agosto";
                                }
                                if ($mesatual == "09") {
                                    $mes = "Setembro";
                                }
                                if ($mesatual == "10") {
                                    $mes = "Outubro";
                                }
                                if ($mesatual == "11") {
                                    $mes = "Novembro";
                                }
                                if ($mesatual == "12") {
                                    $mes = "Dezembro";
                                }
                                include "conexao.php";
                                date_default_timezone_set("America/Cuiaba");
                                $pdo = conectar("membros");
                                $sql = "SELECT * FROM usuarios WHERE userativo = 'S' AND month(datanascimento2) = $mesatual ORDER BY datanascimento ASC";
                                $stmt = $pdo->prepare($sql);
                                $stmt->execute();
                                $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                $totreg = count($registros);
                                ?>
                                <h1>Aniversariantes do M&ecirc;s de <b><?php echo($mes . " (" . $totreg . ")"); ?></b></h1>
                                <?php
                                for ($i = 0; $i < $totreg; $i++) {
                                    $reg = $registros[$i];
                                    $mdata = $reg['datanascimento'];
                                    $sql4 = "SELECT * FROM postograd WHERE id = :idpg";
                                    $stmt4 = $pdo->prepare($sql4);
                                    $stmt4->bindParam(':idpg', $reg['idpgrad'], PDO::PARAM_INT);
                                    $stmt4->execute();
                                    $descpg4 = $stmt4->fetchAll(PDO::FETCH_ASSOC);
                                    $postograd = $descpg4[0];

                                    $meuidsu4 = $reg['idsubunidade'];
                                    $sql5 = "SELECT * FROM subunidade WHERE id = :idsu";
                                    $stmt5 = $pdo->prepare($sql5);
                                    $stmt5->bindParam(':idsu', $meuidsu4, PDO::PARAM_INT);
                                    $stmt5->execute();
                                    $descsu4 = $stmt5->fetchAll(PDO::FETCH_ASSOC);
                                    $SUnidade4 = $descsu4[0];
                                    echo("<br>");
                                    echo("<p>" . $reg['datanascimento'] . " - " . $postograd['pgradsimples'] . " " . $reg['nomeguerra'] . " - " . $SUnidade4['descricao'] . " </p>");
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>                
            </header>           
        </div>
        <div>Seção de Tecnologia da Informação - Sistema desenvolvido pelo 2º Sgt Francês</div>
        <!-- ******************* -->
        <!-- *** JavaScripts *** -->
        <!-- ******************* -->
        <script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/confetti.min.js"></script>
        <script src="assets/js/main.js"></script>
        <!-- switcher -->
        <script src="demo/js/demo.js"></script>

    </body>
</html>
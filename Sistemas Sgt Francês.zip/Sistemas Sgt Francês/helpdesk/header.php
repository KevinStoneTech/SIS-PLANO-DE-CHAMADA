<header>
    <div class="headerpanel">
        <div class="logopanel text-center">
            <?php
            include 'meuip.php';
            ?>
            <h4><a>Sistema Help Desk</a></h4>
        </div>
        <div class="headerbar">
            <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
        </div><!-- headerbar -->
    </div><!-- header-->
</header>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="description" content="Sistema Help Desk">
<meta name="author" content="2º Sgt Francês">
<link rel="shortcut icon" href="images/helpdesk.png" type="image/png">

<title>Help Desk</title>

